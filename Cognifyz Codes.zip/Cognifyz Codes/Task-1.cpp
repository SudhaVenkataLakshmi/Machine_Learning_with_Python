#include<stdio.h>
#include<string.h>
void reverseStrings(char str[]){
	int start = 0;
	int end = strlen(str) - 1;
	char temp;
	while(start < end){
		temp = str[start];
		str[start] = str[end];
		str[end] = temp;
		start++;
		end--;
	}
}
int main(){
	char str[1000];
	printf("Enter a String: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	reverseStrings(str);
	printf("Reversed string: %s\n",str);
	return 0;
}
