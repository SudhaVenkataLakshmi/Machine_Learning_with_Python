#include<stdio.h>
#include<stdlib.h>
#include<time.h>
 main(){
	int target, guess;
	int attempts = 0;
	srand(time(0));
	target = rand() % 100 +1;
	printf("Welcome to the Number Guessing Game! \n");
	printf("I have selected a random number between 1 and 100. Try to guess it! \n");
	do{
		printf("ENter your guess: ");
		scanf("%d", &guess);
		attempts++;
		if(guess < target){
			printf("Higher! Try Again. \n");
		}else if(guess > target){
			printf("Lower! Try Again. \n");
		}else {
			printf("Congratulations! You guessed the correct number %d in %d attempts. \n", target, attempts);
		}
	}while (guess != target);
	return 0;
}
