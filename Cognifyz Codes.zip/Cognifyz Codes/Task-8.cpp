#include<stdio.h>
void sortingAsc(int arr[], int n){
	int temp;
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(arr[j]>arr[j+1]){
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
}
void sortingDec(int arr[], int n){
	int temp;
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(arr[j]<arr[j + 1]){
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
}
void printArray(int arr[],int n){
	for(int i=0;i<n;i++){
		printf("%d ", arr[i]);
	}
	printf("\n");
}
int main(){
	int n, choice;
	printf("Enter the number of elements: ");
	scanf("%d", &n);
	int arr[n];
	printf("Enter the elements of array: ");
	for(int i=0;i<n;i++){
		scanf("%d", &arr[i]);
	}
	printf("1. Acending\n");
	printf("1. Descending\n");
	printf("Enter your choice (1 or 2): ");
	scanf("%d",&choice);
	if(choice == 1){
		sortingAsc(arr, n);
		printf("Array sorted in ascending order: ");
	}else if(choice == 2){
		sortingDec(arr, n);
		printf("Array sorted in descending order: ");
	}else {
		printf("Invalid choice. \n");
		return 1;
	}
	printArray(arr,n);
	return 0;

}
