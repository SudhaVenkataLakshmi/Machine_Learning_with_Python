#include<stdio.h>
void fibonacci(int n){
	int first = 0, second = 1, next;
	if(n >= 1){
		printf("%d",first);
	}
	if(n >= 2){
		printf("%d",second);
	}
	for(int i = 3; i<=n;i++){
		next = first + second;
		printf("%d",next);
		first = second;
		second = next;
	}
	printf("\n");
}
int main(){
	int num_terms;
	printf("Enter the number of terms: ");
	scanf("%d",&num_terms);
	if(num_terms <= 0){
		printf("Please enter a positive integer. \n");
	}else {
		printf("The Fibonacci series upto %d terms: \n", num_terms);
		fibonacci(num_terms);
	}
	return 0;
}
