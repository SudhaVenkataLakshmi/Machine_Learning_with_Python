#include<stdio.h>
#include<string.h>
#include<ctype.h>
int is_palindrome(char str[]){
	int start = 0;
	int end = strlen(str) - 1;
	
	while(start < end){
		if(!isalnum(str[start])){
			start++;
		}else if(!isalnum(str[end])){
			end--;
		}else {
			if(tolower(str[start]) != tolower(str[end])){
				return 0;
			}
			start++;
			end--;
		}
	}
	return 1;
}
int main(){
	char input[1000];
	printf("Enter any word: ");
	fgets(input, sizeof(input), stdin);
	input[strcspn(input,"\n")] = '\0';
	if(is_palindrome(input))
		printf("Given word is a Palindrome. \n");
		else 
		printf("Given word is not a Palindrome. \n");
		return 0;
}
