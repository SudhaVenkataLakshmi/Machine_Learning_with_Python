#include<stdio.h>
int main(){
	int numofSubjects;
	float grade, sum = 0.0, average;
	printf("Enter the number of subjects: ");
	scanf("%d",&numofSubjects);
	if(numofSubjects <= 0){
		printf("The number of subjets must be greater than zero. \n");
		return 1;
	}
	for (int i=1;i<=numofSubjects;i++){
		printf("Enter grade for subject %d: ",i);
		scanf("%f", &grade);
		sum += grade;
	}
	average = sum / numofSubjects;
	printf("The Average Grade is: %.2f\n",average);
	return 0;
}
