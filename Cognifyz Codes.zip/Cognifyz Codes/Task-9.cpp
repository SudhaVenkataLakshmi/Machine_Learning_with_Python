#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void winner(int userChoice, int computerChoice){
	if(userChoice == computerChoice){
		printf("It's a tie! \n'");
	}else if((userChoice == 0 && computerChoice == 2) || (userChoice == 1 && computerChoice == 0) || (userChoice == 2 && computerChoice == 1)){
		printf("You are Winner! \n");
	}else {
		printf("You lose! \n");
	}
}

int main(){
	int userChoice, computerChoice;
	srand(time(0));
	printf("Welcome to Rock-Paper-Scissor Game! \n");
	printf("Enter 0 for Rock, 1 for Paper, or 2 for Scissor: ");
	scanf("%d", &userChoice);
	if(userChoice < 0 || userChoice > 2){
		printf("Invalid input! Please enter 0 or 1 or 2. \n");
		return 1;
	}
	computerChoice = rand()%3;
	if(userChoice == 0){
		printf("You choose Rock.\n");
	}else if(userChoice == 1){
		printf("You choose Paper.\n");
	}else if(userChoice == 2){
		printf("You choose Scissor.\n");
	}
	if(computerChoice == 0){
		printf("Computer choose Rock. \n");
	}else if(computerChoice == 1){
		printf("Computer choose Paper. \n");
	}else if(computerChoice == 2){
		printf("Computer choose Scissor. \n");
	}
	winner(userChoice, computerChoice);
	return 0;
}
